# Private GKE Resoruces

* This directory contains CNRM patches and resource definitions in order
  to deploy Kubeflow on private GKE.